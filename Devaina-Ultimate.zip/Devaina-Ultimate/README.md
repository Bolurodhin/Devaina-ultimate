# Devaina Ultimate AI

This is the ultimate AI assistant project.
Run `bash deviana.sh` to start.
