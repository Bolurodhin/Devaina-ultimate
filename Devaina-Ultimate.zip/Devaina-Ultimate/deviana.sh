#!/bin/bash
python3 deviana.py
